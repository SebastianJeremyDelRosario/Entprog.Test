﻿using AppDbContext.DataModel;
using GenericRepository.DataModel.Repository;
using IProductRepository.App.Models.Repositories;
using ProductsINV.DataModel;

namespace ProductRepository.App.Models.Repositories
{
    public class ProductRepo : GenericRepo<Products>, IProductRepo
    {
        public ProductRepo(AppDBContext context) : base(context)
        {

        }
    }
}

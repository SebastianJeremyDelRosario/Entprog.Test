﻿using IGenericRepository.DataModel.Repository;
using ProductsViewModel.App.Models;
using ProductsINV.DataModel;

namespace IProductRepository.App.Models.Repositories
{
    public interface IProductRepo : IGenericRepo<Products>
    {

    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace Supplier.App.Models
{
    public class SupplierVM
    {
        [Key]
        public int SupplierID { get; set; }
        [Required]
        public string CompanyName { get; set; }
        [Required]
        public string Address { get; set; }
        [Required]
        public string Representative { get; set; }
        [Required]
        public string ContactNo { get; set; }
        public DateTime DateAdded { get; set; }
        public DateTime? DateModified { get; set; }
    }
}

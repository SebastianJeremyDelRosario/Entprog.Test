﻿using System.ComponentModel.DataAnnotations;

namespace ProductsViewModel.App.Models
{
    public class ProductsVM
    {
        [Key]
        public int ProductID { get; set; }

        [Required]
        public string Name { get; set; }
        [Required]
        public string Description { get; set; }
        [Required]
        public int Qty { get; set; }
        [Required]
        public string Unit { get; set; }
        public DateTime DateAdded { get; set; }
        public DateTime? DateModified { get; set; }
    }
}

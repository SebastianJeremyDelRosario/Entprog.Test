﻿using AutoMapper;
using ProductsViewModel.App.Models;
using ProductsINV.DataModel;
using Supplier.App.Models;
using SuppliersINV.DataModel;

namespace Supplier.App.Configuration
{
    public class MapperConfig : Profile
    {
        public MapperConfig()
        {
            CreateMap<Suppliers, SupplierVM>().ReverseMap();
            CreateMap<Products, ProductsVM>().ReverseMap();
        }
    }
}

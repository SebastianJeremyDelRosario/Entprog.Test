﻿using AutoMapper;
using IProductRepository.App.Models.Repositories;
using Microsoft.AspNetCore.Mvc;
using ProductsViewModel.App.Models;
using ProductsINV.DataModel;    

namespace Product.App.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductRepo repo;
        private readonly IMapper mapper;
        public ProductController(IProductRepo repo, IMapper mapper)
        {
            this.repo = repo;
            this.mapper = mapper;
        }
        public async Task<IActionResult> Index()
        {
            return View(mapper.Map<List<ProductsVM>>(await repo.GetAllAsync()));
        }

        public IActionResult Add()
        {
            return View(new ProductsVM());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(ProductsVM model)
        {
            if (ModelState.IsValid)
            {
                model.DateAdded = DateTime.Now;
                await repo.AddAsync(mapper.Map<Products>(model));
                return RedirectToAction("Index");
            }
            else
            {
                return View(model);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int ProductID)
        {
            var product = await repo.GetAsync(ProductID);
            if (product == null)
            {
                return RedirectToAction("Index");
            }

            await repo.DeleteAsync(ProductID);

            return RedirectToAction("Index");
        }
        
        public async Task<IActionResult> Edit(int? ID)
        {
            if (ID == null) return RedirectToAction("Index");
            ProductsVM product = mapper.Map<ProductsVM>(await repo.GetAsync((int)ID));
            return View(product);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(ProductsVM model)
        {
            if (ModelState.IsValid)
            {
                model.DateModified = DateTime.Now;
                await repo.UpdateAsync(mapper.Map<Products>(model));
                return RedirectToAction("Index");
            }
            else 
            { 
                return View(model);
            }
        }
    }
}

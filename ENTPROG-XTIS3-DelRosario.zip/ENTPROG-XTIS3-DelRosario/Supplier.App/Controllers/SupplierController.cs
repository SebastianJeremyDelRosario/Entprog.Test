﻿using AppDbContext.DataModel;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Supplier.App.Models;
using SuppliersINV.DataModel;


namespace Supplier.App.Controllers
{   
    public class SupplierController : Controller
    {
        private readonly AppDBContext context;
        private readonly IMapper mapper;
        public SupplierController(AppDBContext context, IMapper mapper)
        {
            this.context = context;
            this.mapper = mapper;
        }
        public IActionResult Index()
        {
            List<SupplierVM> list = mapper.Map<List<SupplierVM>>(context.SuppliersINV.ToList());
            return View(list);
        }

        public IActionResult Add()
        {
            return View(new SupplierVM());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(SupplierVM model)
        {
            Suppliers entity = mapper.Map<Suppliers>(model);
            model.DateAdded = DateTime.Now;
            await context.AddAsync(model);
            //dbc.Set<Suppliers>().Add(model);
            await context.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int SupplierID)
        {
            var supplier = await context.SuppliersINV.FindAsync(SupplierID);
            context.Set<Suppliers>().Remove(supplier);
            await context.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Edit(int? ID)
        {
            if (ID == null) return RedirectToAction("Index");
            SupplierVM supplier = mapper.Map<SupplierVM>(await context.SuppliersINV.FindAsync(ID));

            return View(supplier);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(SupplierVM model)
        {
            model.DateModified = DateTime.Now;
            context.Set<Suppliers>().Update(mapper.Map<Suppliers>(model));
            await context.SaveChangesAsync();
            return RedirectToAction("Index");
        }


    }
}

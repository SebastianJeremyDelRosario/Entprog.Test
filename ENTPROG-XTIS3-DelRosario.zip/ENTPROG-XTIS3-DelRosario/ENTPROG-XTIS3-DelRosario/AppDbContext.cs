﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using ProductsINV.DataModel;
using SuppliersINV.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppDbContext.DataModel
{
    public class AppDBContext : DbContext
    {
        public AppDBContext(DbContextOptions options) : base(options)
        {
            
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (optionsBuilder.IsConfigured == false)
            {
                //optionsBuilder.UseSqlServer(
                    //"Server=DESKTOP-HK7U63L\\SqlExpress;" +
                    //"Database=Programming_Entprog;Integrated Security=SSPI;" +
                    //"TrustServerCertificate=true");

                //optionsBuilder.UseSqlServer(
                //    "Server=Desktop-Edg1in1\\SqlExpress;" +
                //    "Database=SuppliersINV;Integrated Security=SSPI;" +
                //    "TrustServerCertificate=true");
            }
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Suppliers>().HasData(
               new Suppliers
               {
                   SupplierID = 1,
                   CompanyName = "Adidas",
                   Address = "Metro Manila",
                   Representative = "Sebastian Del Rosario",
                   ContactNo = "09567543321",
                   DateAdded = DateTime.Now,
                   DateModified = null

               }
               );

        }

            public DbSet<Suppliers> SuppliersINV { get; set; }
            public DbSet<Products  > ProductsINV { get; set; }
    }
}

    


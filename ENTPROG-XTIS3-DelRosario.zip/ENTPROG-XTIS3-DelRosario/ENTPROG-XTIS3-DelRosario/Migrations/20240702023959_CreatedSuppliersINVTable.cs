﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ENTPROG_XTIS3_DelRosario.Migrations
{
    /// <inheritdoc />
    public partial class CreatedSuppliersINVTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "SuppliersINV",
                columns: new[] { "SupplierID", "Address", "CompanyName", "ContactNo", "DateAdded", "DateModified", "Representative" },
                values: new object[] { 1, "Metro Manila", "Adidas", "09567543321", new DateTime(2024, 7, 2, 10, 39, 58, 302, DateTimeKind.Local).AddTicks(8773), null, "Sebastian Del Rosario" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "SuppliersINV",
                keyColumn: "SupplierID",
                keyValue: 1);
        }
    }
}

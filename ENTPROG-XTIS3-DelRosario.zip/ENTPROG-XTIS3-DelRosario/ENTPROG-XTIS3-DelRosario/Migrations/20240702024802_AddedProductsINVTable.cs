﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ENTPROG_XTIS3_DelRosario.Migrations
{
    /// <inheritdoc />
    public partial class AddedProductsINVTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ProductsINV",
                columns: table => new
                {
                    ProductID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Qty = table.Column<int>(type: "int", nullable: false),
                    Unit = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DateAdded = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DateModified = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductsINV", x => x.ProductID);
                });

            migrationBuilder.UpdateData(
                table: "SuppliersINV",
                keyColumn: "SupplierID",
                keyValue: 1,
                column: "DateAdded",
                value: new DateTime(2024, 7, 2, 10, 48, 1, 699, DateTimeKind.Local).AddTicks(3653));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ProductsINV");

            migrationBuilder.UpdateData(
                table: "SuppliersINV",
                keyColumn: "SupplierID",
                keyValue: 1,
                column: "DateAdded",
                value: new DateTime(2024, 7, 2, 10, 39, 58, 302, DateTimeKind.Local).AddTicks(8773));
        }
    }
}

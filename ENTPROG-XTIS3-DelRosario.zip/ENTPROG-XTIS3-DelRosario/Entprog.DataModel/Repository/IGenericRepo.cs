﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IGenericRepository.DataModel.Repository
{
    public interface IGenericRepo<T> where T : class
    {
        Task<T> AddAsync(T entity);
        Task<List<T>> GetAllAsync();
        Task DeleteAsync(int ID);
        Task<T> GetAsync(int ID);
        Task UpdateAsync(T entity);
        Task<bool> Exists(int ID);
    }
}
